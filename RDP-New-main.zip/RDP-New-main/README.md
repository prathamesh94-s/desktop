# Windows Server 2019 Github-Ngrok with RDP Access [Region US/EU/AU]
Free RDP Only for learning!
- Visit  https://dashboard.ngrok.com to copy NGROK_AUTH_TOKEN
- Onpage Github: Settings > Secrets > New repository secret

Don't use for mining or hacking!!!

Please support my channel:
- https://www.youtube.com/c/AkaShinobi



